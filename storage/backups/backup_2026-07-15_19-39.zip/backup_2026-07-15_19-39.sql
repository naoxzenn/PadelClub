-- PadelClub Database Backup
-- Generated at: 2026-07-15 14:39:15
SET FOREIGN_KEY_CHECKS=0;

-- --------------------------------------------------------
-- Table structure for table `bookings`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `bookings`;
CREATE TABLE `bookings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `court_id` int(11) NOT NULL,
  `tanggal_booking` date NOT NULL,
  `jam_mulai` time NOT NULL,
  `jam_selesai` time NOT NULL,
  `total_harga` decimal(10,2) NOT NULL,
  `paket` enum('per_jam','per_match') DEFAULT 'per_jam',
  `sewa_raket` tinyint(1) DEFAULT 0,
  `catatan` text DEFAULT NULL,
  `status` enum('pending','confirmed','cancelled') DEFAULT 'pending',
  `cancelled_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `court_id` (`court_id`),
  CONSTRAINT `User` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `lapangan` FOREIGN KEY (`court_id`) REFERENCES `courts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `bookings`
INSERT INTO `bookings` (`id`, `user_id`, `court_id`, `tanggal_booking`, `jam_mulai`, `jam_selesai`, `total_harga`, `paket`, `sewa_raket`, `catatan`, `status`, `cancelled_at`, `created_at`) VALUES 
('1', '2', '2', '2026-05-25', '16:00:00', '20:00:00', '600000.00', '', '0', '', 'confirmed', NULL, '2026-05-13 11:41:00'),
('2', '3', '2', '2026-06-03', '20:00:00', '22:00:00', '350000.00', '', '1', '', 'confirmed', NULL, '2026-05-13 11:48:41'),
('3', '3', '1', '2026-05-20', '18:00:00', '20:00:00', '300000.00', '', '0', '', 'confirmed', NULL, '2026-05-13 14:03:52'),
('4', '3', '2', '2026-05-21', '20:00:00', '22:00:00', '350000.00', '', '1', '', 'confirmed', NULL, '2026-05-13 14:05:19'),
('5', '3', '1', '2026-05-20', '20:00:00', '22:00:00', '300000.00', '', '0', '', 'confirmed', NULL, '2026-05-13 14:25:24'),
('6', '4', '3', '2026-06-27', '20:30:00', '22:30:00', '200000.00', '', '0', '', 'cancelled', NULL, '2026-06-27 17:15:17'),
('7', '4', '2', '2026-06-29', '18:00:00', '21:30:00', '525000.00', '', '0', '', 'cancelled', NULL, '2026-06-27 17:30:26'),
('8', '4', '3', '2026-06-29', '18:00:00', '20:00:00', '200000.00', '', '0', '', 'cancelled', NULL, '2026-06-27 17:32:36'),
('9', '4', '2', '2026-06-29', '15:00:00', '19:00:00', '600000.00', '', '0', '', 'confirmed', NULL, '2026-06-27 17:44:03'),
('10', '5', '1', '2026-07-28', '16:00:00', '20:45:00', '762500.00', '', '1', '', 'confirmed', NULL, '2026-06-27 19:30:39'),
('11', '9', '2', '2026-08-04', '08:45:00', '10:30:00', '262500.00', '', '0', '', 'confirmed', NULL, '2026-07-08 14:01:42');

-- --------------------------------------------------------
-- Table structure for table `courts`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `courts`;
CREATE TABLE `courts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_lapangan` varchar(100) NOT NULL,
  `tipe_lapangan` enum('Indoor','Outdoor') NOT NULL,
  `harga_per_jam` decimal(10,2) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `status` enum('aktif','nonaktif') DEFAULT 'aktif',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `courts`
INSERT INTO `courts` (`id`, `nama_lapangan`, `tipe_lapangan`, `harga_per_jam`, `deskripsi`, `status`, `created_at`) VALUES 
('1', 'Lapangan A', 'Indoor', '150000.00', 'Lapangan indoor ber-AC dengan lantai vinyl premium', 'aktif', '2026-05-13 11:33:07'),
('2', 'Lapangan B', 'Indoor', '150000.00', 'Lapangan indoor standar dengan pencahayaan LED', 'aktif', '2026-05-13 11:33:07'),
('3', 'Lapangan C', 'Outdoor', '100000.00', 'Lapangan outdoor dengan view taman yang indah', 'aktif', '2026-05-13 11:33:07'),
('4', 'Lapangan D', 'Outdoor', '100000.00', 'Lapangan outdoor dengan permukaan artificial grass', 'aktif', '2026-05-13 11:33:07');

-- --------------------------------------------------------
-- Table structure for table `payments`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `booking_id` int(11) NOT NULL,
  `waktu_bayar` datetime DEFAULT current_timestamp(),
  `jumlah_bayar` decimal(10,2) NOT NULL,
  `metode_bayar` enum('Transfer','Cash') NOT NULL,
  `bukti_transfer` varchar(255) DEFAULT NULL,
  `status_verifikasi` enum('menunggu','terverifikasi','ditolak') DEFAULT 'menunggu',
  `payment_status` enum('unpaid','paid') DEFAULT 'unpaid',
  `payment_date` datetime DEFAULT NULL,
  `cashier_id` int(11) DEFAULT NULL,
  `receipt_number` varchar(100) DEFAULT NULL,
  `receipt_printed` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `booking_id` (`booking_id`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `payments`
INSERT INTO `payments` (`id`, `booking_id`, `waktu_bayar`, `jumlah_bayar`, `metode_bayar`, `bukti_transfer`, `status_verifikasi`, `payment_status`, `payment_date`, `cashier_id`, `receipt_number`, `receipt_printed`, `created_at`, `updated_at`) VALUES 
('1', '1', '2026-05-13 11:41:09', '600000.00', 'Cash', '', 'terverifikasi', 'unpaid', NULL, NULL, NULL, '0', '2026-06-27 18:49:50', '2026-06-27 18:49:50'),
('2', '2', '2026-05-13 11:48:45', '350000.00', 'Cash', '', 'menunggu', 'unpaid', NULL, NULL, NULL, '0', '2026-06-27 18:49:50', '2026-06-27 18:49:50'),
('3', '3', '2026-05-13 14:04:06', '300000.00', 'Cash', '', 'menunggu', 'unpaid', NULL, NULL, NULL, '0', '2026-06-27 18:49:50', '2026-06-27 18:49:50'),
('4', '4', '2026-05-13 14:19:15', '350000.00', 'Transfer', 'bukti_4_1778656755.jpg', 'menunggu', 'unpaid', NULL, NULL, NULL, '0', '2026-06-27 18:49:50', '2026-06-27 18:49:50'),
('5', '5', '2026-05-13 14:26:24', '300000.00', 'Transfer', 'bukti_5_1778657184.jpg', 'terverifikasi', 'unpaid', NULL, NULL, NULL, '0', '2026-06-27 18:49:50', '2026-06-27 18:49:50'),
('6', '9', '2026-06-27 17:44:13', '600000.00', 'Cash', '', 'terverifikasi', 'paid', '2026-06-27 14:01:52', '6', 'REC-20260627-0009', '1', '2026-06-27 18:49:50', '2026-06-27 19:01:57'),
('7', '10', '2026-06-27 19:30:46', '762500.00', 'Cash', '', 'terverifikasi', 'paid', '2026-07-02 08:26:45', '6', 'REC-20260702-0010', '1', '2026-06-27 19:30:46', '2026-07-02 13:26:47'),
('8', '11', '2026-07-08 14:01:56', '262500.00', 'Cash', '', 'menunggu', 'unpaid', NULL, NULL, NULL, '0', '2026-07-08 14:01:56', '2026-07-08 14:01:56');

-- --------------------------------------------------------
-- Table structure for table `users`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_lengkap` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `clerk_user_id` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `nomor_telepon` varchar(20) DEFAULT NULL,
  `role` enum('admin','kasir','customer') NOT NULL DEFAULT 'customer',
  `google_id` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `login_provider` enum('local','google') DEFAULT 'local',
  `email_verified` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `clerk_user_id` (`clerk_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `users`
INSERT INTO `users` (`id`, `nama_lengkap`, `email`, `clerk_user_id`, `password`, `nomor_telepon`, `role`, `google_id`, `avatar`, `login_provider`, `email_verified`, `created_at`) VALUES 
('1', 'Administrator', 'admin@padelmania.com', NULL, 'adminmania', '081234567890', 'admin', NULL, NULL, 'local', '0', '2026-05-13 11:33:05'),
('2', 'zaenal arief', 'zaenlips4@gmail.com', NULL, '$2y$10$uigHox52Zori5fUOE5H7z.BLJHTmD3W5sDASU/0Hph5KnUnDduEO6', '0812971392', 'admin', NULL, NULL, 'local', '0', '2026-05-13 11:40:08'),
('3', 'Arga Putra', 'argagamteng@gmail.com', NULL, '$2y$10$2OVYZ5XOJ7vlDC/tVc5AxeSiV0ZoVfUOi93aoqTF2mL/4bHRoAnHK', '018472189', 'customer', NULL, NULL, 'local', '0', '2026-05-13 11:47:33'),
('4', 'Almer', 'Almer45@gmail.com', NULL, '$2y$10$bIECJZYxCvm7aoYXIXG1DeHn/M7aFrF/pqH3oXPnrAdaCDSZSjm.G', '082233009810', 'customer', NULL, NULL, 'local', '0', '2026-06-27 17:13:26'),
('5', 'amba', 'amba69@gmail.com', NULL, '123456', '0893292183', 'customer', NULL, NULL, 'local', '0', '2026-06-27 18:11:55'),
('6', 'Kasir PadelClub', 'kasir@padelclub.com', NULL, 'kasir123', '081234567890', 'kasir', NULL, NULL, 'local', '0', '2026-06-27 18:55:15'),
('7', 'Administrator', 'admin@MyPadel.com', NULL, 'password', '081234567890', 'admin', NULL, NULL, 'local', '0', '2026-06-27 19:00:29'),
('8', 'Kasir Utama', 'kasir@MyPadel.com', NULL, '$2y$10$RWXUM/kZLY2Yd15RYB1X4uqQ8iaiowRgS7O6Ei.eF2H2DUiVGs00e', '089876543210', 'kasir', NULL, NULL, 'local', '0', '2026-06-27 19:00:29'),
('9', 'zupar', 'zupar55@gmail.com', NULL, '123456', '0832193009', 'customer', NULL, NULL, 'local', '0', '2026-07-08 13:42:46'),
('10', 'kasir', 'padel@padelclub.com', NULL, '123456', '08269696969', 'kasir', NULL, NULL, 'local', '0', '2026-07-08 14:56:53'),
('11', 'admin', 'ambamin@padelclub.com', NULL, '123456', '0826789015', 'admin', NULL, NULL, 'local', '0', '2026-07-08 14:58:01'),
('12', 'Zainl Zee', 'zainlzee52@gmail.com', NULL, '097605a25392277b618954e3fb5bd0cf', NULL, 'customer', '106968381419847277419', 'https://lh3.googleusercontent.com/a/ACg8ocIZM1I6iAe356kGv00_yuBcBZrQP3WJ9WJ2vQ_GJn-DnJ6hHw=s96-c', 'google', '1', '2026-07-15 14:30:23');

SET FOREIGN_KEY_CHECKS=1;
